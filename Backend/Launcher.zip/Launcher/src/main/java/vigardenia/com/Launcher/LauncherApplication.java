package vigardenia.com.Launcher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LauncherApplication {

	public static void main(String[] args) {
		SpringApplication.run(LauncherApplication.class, args);
	}

}
